package web_src;


import java.io.IOException;
import java.io.PrintWriter;

//Import required java libraries

import javax.servlet.*;
import javax.servlet.http.*;

//Extend HttpServlet class
public class testServlet extends HttpServlet {

private String message;

public void init() throws ServletException
{
   // Do required initialization
   message = "Hello World2";
}

public void doGet(HttpServletRequest request,
                 HttpServletResponse response)
         throws ServletException, IOException
{
   // Set response content type
   response.setContentType("text/html");

   RequestDispatcher rd = request.getRequestDispatcher("EuphoricGardens/Home/HTML/EuphoricGardens.html");
   rd.forward(request, response);
   //response.sendRedirect("EuphoricGardens/Home/HTML/home.html");
}

public void destroy()
{
   // do nothing.
}
}
